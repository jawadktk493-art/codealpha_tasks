// Lightweight JSON-file-backed "database".
// Simple enough for a mini social app; swap for a real DB (Postgres/Mongo) in production.
const fs = require('fs');
const path = require('path');

const DB_FILE = path.join(__dirname, 'data.json');

const DEFAULT_DATA = {
  users: [],       // { id, username, email, passwordHash, bio, avatar, createdAt }
  posts: [],       // { id, userId, content, image, createdAt }
  comments: [],    // { id, postId, userId, content, createdAt }
  likes: [],       // { id, postId, userId, createdAt }
  follows: [],     // { id, followerId, followingId, createdAt }
  nextId: { users: 1, posts: 1, comments: 1, likes: 1, follows: 1 }
};

function load() {
  if (!fs.existsSync(DB_FILE)) {
    fs.writeFileSync(DB_FILE, JSON.stringify(DEFAULT_DATA, null, 2));
  }
  return JSON.parse(fs.readFileSync(DB_FILE, 'utf-8'));
}

function save(data) {
  fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2));
}

// In-memory cache, persisted to disk on every mutation (fine for a mini app's scale).
let data = load();

function nextId(table) {
  const id = data.nextId[table]++;
  return id;
}

function persist() {
  save(data);
}

module.exports = { data, nextId, persist };
