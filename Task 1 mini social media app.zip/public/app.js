(() => {
  const API = '/api';
  const state = {
    token: localStorage.getItem('wire_token') || null,
    user: null,       // current logged-in user (public profile shape)
    route: 'feed',    // feed | following | search | profile
    viewingUserId: null
  };

  // ---------- API helper ----------
  async function api(path, { method = 'GET', body } = {}) {
    const headers = { 'Content-Type': 'application/json' };
    if (state.token) headers.Authorization = `Bearer ${state.token}`;
    const res = await fetch(API + path, {
      method,
      headers,
      body: body ? JSON.stringify(body) : undefined
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.error || 'Something went wrong');
    return data;
  }

  function toast(msg) {
    const el = document.createElement('div');
    el.className = 'toast';
    el.textContent = msg;
    document.body.appendChild(el);
    setTimeout(() => el.remove(), 2400);
  }

  function timeAgo(iso) {
    const diff = (Date.now() - new Date(iso).getTime()) / 1000;
    if (diff < 60) return 'just now';
    if (diff < 3600) return Math.floor(diff / 60) + 'm ago';
    if (diff < 86400) return Math.floor(diff / 3600) + 'h ago';
    if (diff < 604800) return Math.floor(diff / 86400) + 'd ago';
    return new Date(iso).toLocaleDateString();
  }

  function escapeHtml(str) {
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
  }

  // ---------- Auth view wiring ----------
  const authView = document.getElementById('auth-view');
  const appView = document.getElementById('app-view');
  const loginForm = document.getElementById('login-form');
  const registerForm = document.getElementById('register-form');
  const loginError = document.getElementById('login-error');
  const registerError = document.getElementById('register-error');

  document.querySelectorAll('.auth-tab').forEach(tab => {
    tab.addEventListener('click', () => {
      document.querySelectorAll('.auth-tab').forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      const isLogin = tab.dataset.tab === 'login';
      loginForm.classList.toggle('hidden', !isLogin);
      registerForm.classList.toggle('hidden', isLogin);
    });
  });

  loginForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    loginError.textContent = '';
    const fd = new FormData(loginForm);
    try {
      const data = await api('/auth/login', { method: 'POST', body: { username: fd.get('username'), password: fd.get('password') } });
      onAuthSuccess(data);
    } catch (err) {
      loginError.textContent = err.message;
    }
  });

  registerForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    registerError.textContent = '';
    const fd = new FormData(registerForm);
    try {
      const data = await api('/auth/register', { method: 'POST', body: { username: fd.get('username'), email: fd.get('email'), password: fd.get('password') } });
      onAuthSuccess(data);
    } catch (err) {
      registerError.textContent = err.message;
    }
  });

  function onAuthSuccess({ token, user }) {
    state.token = token;
    state.user = user;
    localStorage.setItem('wire_token', token);
    authView.classList.add('hidden');
    appView.classList.remove('hidden');
    document.getElementById('rail-user').innerHTML = `Signed in as<br><b>@${escapeHtml(user.username)}</b>`;
    navigate('feed');
  }

  document.getElementById('logout-btn').addEventListener('click', () => {
    state.token = null;
    state.user = null;
    localStorage.removeItem('wire_token');
    appView.classList.add('hidden');
    authView.classList.remove('hidden');
  });

  // ---------- Nav ----------
  document.querySelectorAll('.rail-link').forEach(btn => {
    btn.addEventListener('click', () => navigate(btn.dataset.route));
  });

  function setActiveNav(route) {
    document.querySelectorAll('.rail-link').forEach(b => b.classList.toggle('active', b.dataset.route === route));
  }

  async function navigate(route, opts = {}) {
    state.route = route;
    setActiveNav(route);
    document.getElementById('composer').classList.toggle('hidden', route === 'search' || route === 'profile');
    const heading = document.getElementById('feed-heading');
    const sideCol = document.getElementById('side-col');

    if (route === 'feed') {
      heading.textContent = 'Latest dispatches';
      sideCol.innerHTML = '';
      await loadFeed('/posts');
    } else if (route === 'following') {
      heading.textContent = 'From people you follow';
      sideCol.innerHTML = '';
      await loadFeed('/posts?scope=following');
    } else if (route === 'search') {
      heading.textContent = 'People on WIRE';
      renderSearch();
      document.getElementById('feed').innerHTML = '';
    } else if (route === 'profile') {
      const id = opts.userId || state.user.id;
      state.viewingUserId = id;
      await renderProfile(id);
    }
  }

  document.getElementById('nav-profile').addEventListener('click', () => navigate('profile', { userId: state.user.id }));

  // ---------- Composer ----------
  const composerInput = document.getElementById('composer-input');
  const composerCount = document.getElementById('composer-count');
  composerInput.addEventListener('input', () => {
    composerCount.textContent = (2000 - composerInput.value.length) + ' left';
  });
  document.getElementById('composer-submit').addEventListener('click', async () => {
    const content = composerInput.value.trim();
    if (!content) return;
    try {
      await api('/posts', { method: 'POST', body: { content } });
      composerInput.value = '';
      composerCount.textContent = '2000 left';
      toast('Dispatch published');
      if (state.route === 'feed') loadFeed('/posts');
      else if (state.route === 'following') loadFeed('/posts?scope=following');
    } catch (err) {
      toast(err.message);
    }
  });

  // ---------- Feed rendering ----------
  const feedEl = document.getElementById('feed');
  const tplPost = document.getElementById('tpl-post');
  const tplComment = document.getElementById('tpl-comment');

  async function loadFeed(path) {
    feedEl.innerHTML = '<div class="empty-state">Loading dispatches…</div>';
    try {
      const { posts } = await api(path);
      renderPosts(posts);
    } catch (err) {
      feedEl.innerHTML = `<div class="empty-state">${escapeHtml(err.message)}</div>`;
    }
  }

  function renderPosts(posts) {
    feedEl.innerHTML = '';
    if (!posts.length) {
      feedEl.innerHTML = '<div class="empty-state">No dispatches yet. Be the first to file one.</div>';
      return;
    }
    posts.forEach(post => feedEl.appendChild(buildPostNode(post)));
  }

  function buildPostNode(post) {
    const node = tplPost.content.cloneNode(true);
    const article = node.querySelector('.post');
    article.dataset.postId = post.id;

    const authorBtn = node.querySelector('.post-author');
    authorBtn.textContent = '@' + (post.author ? post.author.username : 'unknown');
    authorBtn.addEventListener('click', () => navigate('profile', { userId: post.author.id }));

    node.querySelector('.post-time').textContent = timeAgo(post.createdAt);
    node.querySelector('.post-content').textContent = post.content;

    const deleteBtn = node.querySelector('.post-delete');
    if (post.author && post.author.id === state.user.id) {
      deleteBtn.addEventListener('click', async () => {
        if (!confirm('Delete this dispatch?')) return;
        try {
          await api(`/posts/${post.id}`, { method: 'DELETE' });
          article.remove();
          toast('Dispatch deleted');
        } catch (err) { toast(err.message); }
      });
    } else {
      deleteBtn.remove();
    }

    const likeBtn = node.querySelector('.like-btn');
    const likeCount = node.querySelector('.like-count');
    likeCount.textContent = post.likeCount;
    likeBtn.classList.toggle('active', post.likedByMe);
    likeBtn.addEventListener('click', async () => {
      try {
        const method = likeBtn.classList.contains('active') ? 'DELETE' : 'POST';
        const { post: updated } = await api(`/posts/${post.id}/like`, { method });
        likeCount.textContent = updated.likeCount;
        likeBtn.classList.toggle('active', updated.likedByMe);
      } catch (err) { toast(err.message); }
    });

    const commentCount = node.querySelector('.comment-count');
    commentCount.textContent = post.commentCount;
    const commentsWrap = node.querySelector('.comments');
    const commentToggle = node.querySelector('.comment-toggle');
    let loaded = false;

    commentToggle.addEventListener('click', async () => {
      commentsWrap.classList.toggle('hidden');
      if (!commentsWrap.classList.contains('hidden') && !loaded) {
        loaded = true;
        await loadComments(post.id, commentsWrap, commentCount);
      }
    });

    return node;
  }

  async function loadComments(postId, wrap, countEl) {
    wrap.innerHTML = '<div class="empty-state" style="padding:10px;">Loading…</div>';
    try {
      const { comments } = await api(`/posts/${postId}/comments`);
      wrap.innerHTML = '';
      comments.forEach(c => wrap.appendChild(buildCommentNode(c, wrap, countEl)));
      const form = document.createElement('form');
      form.className = 'comment-form';
      form.innerHTML = `<input type="text" maxlength="500" placeholder="Write a comment…" required>`;
      form.addEventListener('submit', async (e) => {
        e.preventDefault();
        const input = form.querySelector('input');
        const content = input.value.trim();
        if (!content) return;
        try {
          const { comment } = await api(`/posts/${postId}/comments`, { method: 'POST', body: { content } });
          const node = buildCommentNode(comment, wrap, countEl);
          wrap.insertBefore(node, form);
          input.value = '';
          countEl.textContent = Number(countEl.textContent) + 1;
        } catch (err) { toast(err.message); }
      });
      wrap.appendChild(form);
    } catch (err) {
      wrap.innerHTML = `<div class="empty-state">${escapeHtml(err.message)}</div>`;
    }
  }

  function buildCommentNode(comment, wrap, countEl) {
    const node = tplComment.content.cloneNode(true);
    const container = node.querySelector('.comment');
    const authorBtn = node.querySelector('.comment-author');
    authorBtn.textContent = '@' + (comment.author ? comment.author.username : 'unknown');
    authorBtn.addEventListener('click', () => navigate('profile', { userId: comment.author.id }));
    node.querySelector('.comment-text').textContent = comment.content;
    const delBtn = node.querySelector('.comment-delete');
    if (comment.author && comment.author.id === state.user.id) {
      delBtn.addEventListener('click', async () => {
        try {
          await api(`/comments/${comment.id}`, { method: 'DELETE' });
          container.remove();
          countEl.textContent = Math.max(0, Number(countEl.textContent) - 1);
        } catch (err) { toast(err.message); }
      });
    } else {
      delBtn.remove();
    }
    return node;
  }

  // ---------- Profile view ----------
  async function renderProfile(userId) {
    const sideCol = document.getElementById('side-col');
    document.getElementById('feed-heading').textContent = 'Dispatches';
    feedEl.innerHTML = '<div class="empty-state">Loading…</div>';
    sideCol.innerHTML = '<div class="card">Loading profile…</div>';
    try {
      const { user } = await api(`/users/${userId}`);
      const isMe = user.id === state.user.id;
      sideCol.innerHTML = `
        <div class="card">
          <h2 class="profile-name">@${escapeHtml(user.username)}</h2>
          <p class="profile-bio" id="profile-bio-text">${user.bio ? escapeHtml(user.bio) : '<em>No bio yet.</em>'}</p>
          <div class="profile-stats">
            <div><b>${user.postCount}</b>dispatches</div>
            <div><b>${user.followers}</b>followers</div>
            <div><b>${user.following}</b>following</div>
          </div>
          ${isMe
            ? `<button class="btn btn-small" id="edit-profile-btn">Edit bio</button>
               <div class="profile-edit hidden" id="profile-edit-box">
                 <textarea id="bio-input" maxlength="280" rows="3">${escapeHtml(user.bio || '')}</textarea>
                 <button class="btn btn-primary btn-small" id="save-bio-btn">Save</button>
               </div>`
            : `<button class="btn btn-small" id="follow-btn">${user.isFollowing ? 'Following' : 'Follow'}</button>`
          }
        </div>`;

      if (isMe) {
        const editBtn = document.getElementById('edit-profile-btn');
        const editBox = document.getElementById('profile-edit-box');
        editBtn.addEventListener('click', () => editBox.classList.toggle('hidden'));
        document.getElementById('save-bio-btn').addEventListener('click', async () => {
          const bio = document.getElementById('bio-input').value;
          try {
            const { user: updated } = await api(`/users/${state.user.id}`, { method: 'PUT', body: { bio } });
            document.getElementById('profile-bio-text').textContent = updated.bio || 'No bio yet.';
            editBox.classList.add('hidden');
            toast('Profile updated');
          } catch (err) { toast(err.message); }
        });
      } else {
        const followBtn = document.getElementById('follow-btn');
        followBtn.classList.toggle('active', user.isFollowing);
        followBtn.addEventListener('click', async () => {
          try {
            const method = followBtn.textContent === 'Following' ? 'DELETE' : 'POST';
            await api(`/users/${user.id}/follow`, { method });
            followBtn.textContent = method === 'POST' ? 'Following' : 'Follow';
            toast(method === 'POST' ? `Following @${user.username}` : `Unfollowed @${user.username}`);
          } catch (err) { toast(err.message); }
        });
      }

      const { posts } = await api(`/users/${userId}/posts`);
      renderPosts(posts);
    } catch (err) {
      sideCol.innerHTML = `<div class="card">${escapeHtml(err.message)}</div>`;
      feedEl.innerHTML = '';
    }
  }

  // ---------- Search view ----------
  function renderSearch() {
    const sideCol = document.getElementById('side-col');
    sideCol.innerHTML = `
      <div class="card">
        <p class="card-title">Search by username</p>
        <input type="text" class="search-input" id="user-search-input" placeholder="e.g. ada">
        <div id="user-search-results"></div>
      </div>`;
    const input = document.getElementById('user-search-input');
    const results = document.getElementById('user-search-results');
    let timer;
    input.addEventListener('input', () => {
      clearTimeout(timer);
      timer = setTimeout(async () => {
        const q = input.value.trim();
        if (!q) { results.innerHTML = ''; return; }
        try {
          const { users } = await api(`/search/users?q=${encodeURIComponent(q)}`);
          results.innerHTML = '';
          if (!users.length) {
            results.innerHTML = '<p class="empty-state" style="padding:14px;">No one matches that.</p>';
            return;
          }
          users.forEach(u => results.appendChild(buildUserRow(u)));
        } catch (err) { toast(err.message); }
      }, 250);
    });
  }

  function buildUserRow(user) {
    const tpl = document.getElementById('tpl-user-row');
    const node = tpl.content.cloneNode(true);
    const nameBtn = node.querySelector('.user-row-name');
    nameBtn.textContent = '@' + user.username;
    nameBtn.addEventListener('click', () => navigate('profile', { userId: user.id }));
    node.querySelector('.user-row-bio').textContent = user.bio || '';
    const followBtn = node.querySelector('.follow-btn');
    if (user.id === state.user.id) {
      followBtn.remove();
    } else {
      followBtn.textContent = user.isFollowing ? 'Following' : 'Follow';
      followBtn.addEventListener('click', async () => {
        try {
          const method = followBtn.textContent === 'Following' ? 'DELETE' : 'POST';
          await api(`/users/${user.id}/follow`, { method });
          followBtn.textContent = method === 'POST' ? 'Following' : 'Follow';
        } catch (err) { toast(err.message); }
      });
    }
    return node;
  }

  // ---------- Boot ----------
  async function boot() {
    if (!state.token) return; // stay on auth view
    try {
      const { user } = await api('/auth/me');
      state.user = user;
      authView.classList.add('hidden');
      appView.classList.remove('hidden');
      document.getElementById('rail-user').innerHTML = `Signed in as<br><b>@${escapeHtml(user.username)}</b>`;
      navigate('feed');
    } catch (err) {
      localStorage.removeItem('wire_token');
      state.token = null;
    }
  }

  boot();
})();
