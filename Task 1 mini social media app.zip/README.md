# WIRE — Mini Social Media App

A small full-stack social app: user profiles, posts, comments, likes, and follows.

- **Backend:** Node.js + Express, JWT auth, bcrypt password hashing
- **Database:** a lightweight JSON file store (`db.js` / `data.json`) — zero setup required. The schema is simple relational tables (`users`, `posts`, `comments`, `likes`, `follows`), so it's a straightforward swap to Postgres/MySQL/MongoDB if you want a production-grade DB later.
- **Frontend:** plain HTML / CSS / JavaScript (no build step), served as static files by Express

## Setup

```bash
npm install
npm start
```

Then open **http://localhost:3000**.

The server listens on port `3000` by default (override with `PORT=xxxx npm start`).
On first run it creates `data.json` next to `server.js` — that file is your entire database. Delete it to reset the app.

## Project structure

```
server.js        Express app + all API routes
db.js            JSON-file "database" (users, posts, comments, likes, follows)
auth.js          JWT signing + auth middleware
public/
  index.html     App shell (auth screen + main app)
  style.css      Styling
  app.js         Frontend logic (calls the API, renders the UI)
data.json        Created automatically — your data
```

## Features

- **Accounts:** register / log in (JWT stored in `localStorage`), edit your bio
- **Posts:** create, delete, view in a global feed or a "following only" feed
- **Comments:** add / delete comments on any post
- **Likes:** like / unlike posts
- **Follow system:** follow / unfollow users, follower & following counts, search users by username
- **Profiles:** public profile pages with bio, stats, and that user's posts

## API reference

All endpoints are under `/api`. Protected routes require `Authorization: Bearer <token>`.

| Method | Endpoint                        | Auth | Description |
|--------|----------------------------------|------|--------------|
| POST   | `/auth/register`                | –    | Create an account |
| POST   | `/auth/login`                   | –    | Log in |
| GET    | `/auth/me`                      | ✅   | Current user |
| GET    | `/users/:id`                    | opt  | Public profile |
| PUT    | `/users/:id`                    | ✅   | Update your own bio/avatar |
| GET    | `/users/:id/posts`              | opt  | A user's posts |
| GET    | `/users/:id/followers`          | –    | Followers list |
| GET    | `/users/:id/following`          | –    | Following list |
| POST   | `/users/:id/follow`             | ✅   | Follow a user |
| DELETE | `/users/:id/follow`             | ✅   | Unfollow a user |
| GET    | `/posts`                        | opt  | Feed (`?scope=following` to restrict) |
| POST   | `/posts`                        | ✅   | Create a post |
| GET    | `/posts/:id`                    | opt  | Single post |
| DELETE | `/posts/:id`                    | ✅   | Delete your own post |
| POST   | `/posts/:id/like`               | ✅   | Like a post |
| DELETE | `/posts/:id/like`                | ✅   | Unlike a post |
| GET    | `/posts/:id/comments`           | –    | List comments |
| POST   | `/posts/:id/comments`           | ✅   | Add a comment |
| DELETE | `/comments/:id`                 | ✅   | Delete your own comment |
| GET    | `/search/users?q=`              | –    | Search users by username |

## Notes on the storage layer

`db.js` keeps everything in memory and writes the full state to `data.json` after each mutation. This is intentionally simple so the app runs anywhere with just `npm install && npm start` — no database server, no native build tools, no config. It comfortably handles a demo/small-scale app; if you outgrow it, replace the contents of `db.js` with real queries (e.g. `pg`, `mongoose`, or Django's ORM if you port the backend) while keeping `server.js`'s route logic mostly the same, since it only calls `data.<table>` arrays and `nextId()` / `persist()`.
