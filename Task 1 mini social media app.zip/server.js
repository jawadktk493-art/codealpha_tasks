const express = require('express');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const path = require('path');

const { data, nextId, persist } = require('./db');
const { signToken, authRequired, authOptional } = require('./auth');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// ---------- Helpers ----------

function publicUser(user, viewerId) {
  if (!user) return null;
  const followers = data.follows.filter(f => f.followingId === user.id).length;
  const following = data.follows.filter(f => f.followerId === user.id).length;
  const postCount = data.posts.filter(p => p.userId === user.id).length;
  const isFollowing = viewerId
    ? data.follows.some(f => f.followerId === viewerId && f.followingId === user.id)
    : false;
  return {
    id: user.id,
    username: user.username,
    bio: user.bio || '',
    avatar: user.avatar || '',
    createdAt: user.createdAt,
    followers,
    following,
    postCount,
    isFollowing
  };
}

function serializePost(post, viewerId) {
  const author = data.users.find(u => u.id === post.userId);
  const likeCount = data.likes.filter(l => l.postId === post.id).length;
  const commentCount = data.comments.filter(c => c.postId === post.id).length;
  const likedByMe = viewerId
    ? data.likes.some(l => l.postId === post.id && l.userId === viewerId)
    : false;
  return {
    id: post.id,
    content: post.content,
    image: post.image || '',
    createdAt: post.createdAt,
    author: author ? { id: author.id, username: author.username, avatar: author.avatar || '' } : null,
    likeCount,
    commentCount,
    likedByMe
  };
}

function serializeComment(comment) {
  const author = data.users.find(u => u.id === comment.userId);
  return {
    id: comment.id,
    content: comment.content,
    createdAt: comment.createdAt,
    postId: comment.postId,
    author: author ? { id: author.id, username: author.username, avatar: author.avatar || '' } : null
  };
}

function isEmail(str) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(str);
}

// ---------- Auth routes ----------

app.post('/api/auth/register', async (req, res) => {
  const { username, email, password, bio } = req.body || {};
  if (!username || !email || !password) {
    return res.status(400).json({ error: 'username, email and password are required' });
  }
  if (username.length < 3) return res.status(400).json({ error: 'Username must be at least 3 characters' });
  if (!isEmail(email)) return res.status(400).json({ error: 'Invalid email address' });
  if (password.length < 6) return res.status(400).json({ error: 'Password must be at least 6 characters' });

  const exists = data.users.some(u => u.username.toLowerCase() === username.toLowerCase() || u.email.toLowerCase() === email.toLowerCase());
  if (exists) return res.status(409).json({ error: 'Username or email already in use' });

  const passwordHash = await bcrypt.hash(password, 10);
  const user = {
    id: nextId('users'),
    username,
    email,
    passwordHash,
    bio: bio || '',
    avatar: '',
    createdAt: new Date().toISOString()
  };
  data.users.push(user);
  persist();

  const token = signToken(user);
  res.status(201).json({ token, user: publicUser(user, user.id) });
});

app.post('/api/auth/login', async (req, res) => {
  const { username, password } = req.body || {};
  if (!username || !password) return res.status(400).json({ error: 'username and password are required' });

  const user = data.users.find(u => u.username.toLowerCase() === username.toLowerCase() || u.email.toLowerCase() === username.toLowerCase());
  if (!user) return res.status(401).json({ error: 'Invalid credentials' });

  const ok = await bcrypt.compare(password, user.passwordHash);
  if (!ok) return res.status(401).json({ error: 'Invalid credentials' });

  const token = signToken(user);
  res.json({ token, user: publicUser(user, user.id) });
});

app.get('/api/auth/me', authRequired, (req, res) => {
  const user = data.users.find(u => u.id === req.user.id);
  if (!user) return res.status(404).json({ error: 'User not found' });
  res.json({ user: publicUser(user, user.id) });
});

// ---------- User routes ----------

app.get('/api/users/:id', authOptional, (req, res) => {
  const user = data.users.find(u => u.id === Number(req.params.id));
  if (!user) return res.status(404).json({ error: 'User not found' });
  res.json({ user: publicUser(user, req.user && req.user.id) });
});

app.put('/api/users/:id', authRequired, (req, res) => {
  const id = Number(req.params.id);
  if (id !== req.user.id) return res.status(403).json({ error: 'You can only edit your own profile' });
  const user = data.users.find(u => u.id === id);
  if (!user) return res.status(404).json({ error: 'User not found' });

  const { bio, avatar } = req.body || {};
  if (typeof bio === 'string') user.bio = bio.slice(0, 280);
  if (typeof avatar === 'string') user.avatar = avatar;
  persist();
  res.json({ user: publicUser(user, user.id) });
});

app.get('/api/users/:id/posts', authOptional, (req, res) => {
  const id = Number(req.params.id);
  const posts = data.posts
    .filter(p => p.userId === id)
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
    .map(p => serializePost(p, req.user && req.user.id));
  res.json({ posts });
});

app.get('/api/users/:id/followers', (req, res) => {
  const id = Number(req.params.id);
  const followers = data.follows
    .filter(f => f.followingId === id)
    .map(f => data.users.find(u => u.id === f.followerId))
    .filter(Boolean)
    .map(u => publicUser(u));
  res.json({ followers });
});

app.get('/api/users/:id/following', (req, res) => {
  const id = Number(req.params.id);
  const following = data.follows
    .filter(f => f.followerId === id)
    .map(f => data.users.find(u => u.id === f.followingId))
    .filter(Boolean)
    .map(u => publicUser(u));
  res.json({ following });
});

app.post('/api/users/:id/follow', authRequired, (req, res) => {
  const targetId = Number(req.params.id);
  if (targetId === req.user.id) return res.status(400).json({ error: "You can't follow yourself" });
  const target = data.users.find(u => u.id === targetId);
  if (!target) return res.status(404).json({ error: 'User not found' });

  const already = data.follows.some(f => f.followerId === req.user.id && f.followingId === targetId);
  if (already) return res.status(409).json({ error: 'Already following' });

  data.follows.push({ id: nextId('follows'), followerId: req.user.id, followingId: targetId, createdAt: new Date().toISOString() });
  persist();
  res.status(201).json({ user: publicUser(target, req.user.id) });
});

app.delete('/api/users/:id/follow', authRequired, (req, res) => {
  const targetId = Number(req.params.id);
  const idx = data.follows.findIndex(f => f.followerId === req.user.id && f.followingId === targetId);
  if (idx === -1) return res.status(404).json({ error: 'Not following this user' });
  data.follows.splice(idx, 1);
  persist();
  const target = data.users.find(u => u.id === targetId);
  res.json({ user: publicUser(target, req.user.id) });
});

// ---------- Post routes ----------

app.get('/api/posts', authOptional, (req, res) => {
  // Feed: newest first. ?scope=following restricts to people the viewer follows.
  let posts = data.posts;
  if (req.query.scope === 'following' && req.user) {
    const followingIds = new Set(data.follows.filter(f => f.followerId === req.user.id).map(f => f.followingId));
    posts = posts.filter(p => followingIds.has(p.userId) || p.userId === req.user.id);
  }
  posts = posts.slice().sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  res.json({ posts: posts.map(p => serializePost(p, req.user && req.user.id)) });
});

app.post('/api/posts', authRequired, (req, res) => {
  const { content, image } = req.body || {};
  if (!content || !content.trim()) return res.status(400).json({ error: 'Post content cannot be empty' });
  if (content.length > 2000) return res.status(400).json({ error: 'Post is too long (max 2000 characters)' });

  const post = {
    id: nextId('posts'),
    userId: req.user.id,
    content: content.trim(),
    image: image || '',
    createdAt: new Date().toISOString()
  };
  data.posts.push(post);
  persist();
  res.status(201).json({ post: serializePost(post, req.user.id) });
});

app.get('/api/posts/:id', authOptional, (req, res) => {
  const post = data.posts.find(p => p.id === Number(req.params.id));
  if (!post) return res.status(404).json({ error: 'Post not found' });
  res.json({ post: serializePost(post, req.user && req.user.id) });
});

app.delete('/api/posts/:id', authRequired, (req, res) => {
  const idx = data.posts.findIndex(p => p.id === Number(req.params.id));
  if (idx === -1) return res.status(404).json({ error: 'Post not found' });
  if (data.posts[idx].userId !== req.user.id) return res.status(403).json({ error: 'You can only delete your own posts' });

  const postId = data.posts[idx].id;
  data.posts.splice(idx, 1);
  data.comments = data.comments.filter(c => c.postId !== postId);
  data.likes = data.likes.filter(l => l.postId !== postId);
  persist();
  res.json({ success: true });
});

app.post('/api/posts/:id/like', authRequired, (req, res) => {
  const postId = Number(req.params.id);
  const post = data.posts.find(p => p.id === postId);
  if (!post) return res.status(404).json({ error: 'Post not found' });

  const already = data.likes.some(l => l.postId === postId && l.userId === req.user.id);
  if (already) return res.status(409).json({ error: 'Already liked' });

  data.likes.push({ id: nextId('likes'), postId, userId: req.user.id, createdAt: new Date().toISOString() });
  persist();
  res.status(201).json({ post: serializePost(post, req.user.id) });
});

app.delete('/api/posts/:id/like', authRequired, (req, res) => {
  const postId = Number(req.params.id);
  const idx = data.likes.findIndex(l => l.postId === postId && l.userId === req.user.id);
  if (idx === -1) return res.status(404).json({ error: 'You have not liked this post' });
  data.likes.splice(idx, 1);
  persist();
  const post = data.posts.find(p => p.id === postId);
  res.json({ post: serializePost(post, req.user.id) });
});

// ---------- Comment routes ----------

app.get('/api/posts/:id/comments', (req, res) => {
  const postId = Number(req.params.id);
  const comments = data.comments
    .filter(c => c.postId === postId)
    .sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt))
    .map(serializeComment);
  res.json({ comments });
});

app.post('/api/posts/:id/comments', authRequired, (req, res) => {
  const postId = Number(req.params.id);
  const post = data.posts.find(p => p.id === postId);
  if (!post) return res.status(404).json({ error: 'Post not found' });

  const { content } = req.body || {};
  if (!content || !content.trim()) return res.status(400).json({ error: 'Comment cannot be empty' });
  if (content.length > 500) return res.status(400).json({ error: 'Comment is too long (max 500 characters)' });

  const comment = {
    id: nextId('comments'),
    postId,
    userId: req.user.id,
    content: content.trim(),
    createdAt: new Date().toISOString()
  };
  data.comments.push(comment);
  persist();
  res.status(201).json({ comment: serializeComment(comment) });
});

app.delete('/api/comments/:id', authRequired, (req, res) => {
  const idx = data.comments.findIndex(c => c.id === Number(req.params.id));
  if (idx === -1) return res.status(404).json({ error: 'Comment not found' });
  if (data.comments[idx].userId !== req.user.id) return res.status(403).json({ error: 'You can only delete your own comments' });
  data.comments.splice(idx, 1);
  persist();
  res.json({ success: true });
});

// ---------- Search ----------

app.get('/api/search/users', (req, res) => {
  const q = (req.query.q || '').toLowerCase().trim();
  if (!q) return res.json({ users: [] });
  const users = data.users
    .filter(u => u.username.toLowerCase().includes(q))
    .slice(0, 20)
    .map(u => publicUser(u));
  res.json({ users });
});

// Fallback to SPA index for any non-API route
app.get(/^(?!\/api).*/, (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`Social app server running at http://localhost:${PORT}`);
});
