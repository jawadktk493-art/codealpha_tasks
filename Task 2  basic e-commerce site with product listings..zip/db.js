// Lightweight JSON-file-backed "database". No native build tools required.
// Swap the contents of this file for real queries (Postgres/Mongo/etc.) if you
// outgrow it — server.js only ever touches data.<table> arrays plus nextId()/persist().
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const DB_FILE = path.join(__dirname, 'data.json');

const SEED_PRODUCTS = [
  { sku: 'FS-1001', name: 'Canvas Field Jacket', category: 'Apparel', price: 12800, stock: 14,
    description: 'Waxed 12oz canvas, corduroy collar, four bellows pockets. Built to take a beating and only look better for it.', icon: '🧥' },
  { sku: 'FS-1002', name: 'Enamel Camp Mug, 16oz', category: 'Kitchen', price: 1600, stock: 42,
    description: 'Classic speckled enamel over steel. Goes straight from the fire to your hand without complaint.', icon: '☕' },
  { sku: 'FS-1003', name: 'Fixed-Blade Bushcraft Knife', category: 'Tools', price: 8900, stock: 9,
    description: 'Full-tang 1095 carbon steel, scandi grind, leather sheath included. Sharpens fast, holds an edge.', icon: '🔪' },
  { sku: 'FS-1004', name: 'Merino Wool Base Layer', category: 'Apparel', price: 6400, stock: 23,
    description: '260gsm merino, flatlock seams. Regulates temperature whether it is 20 degrees or 60.', icon: '👕' },
  { sku: 'FS-1005', name: 'Cast Iron Skillet, 10in', category: 'Kitchen', price: 4200, stock: 31,
    description: 'Pre-seasoned, made for a lifetime of camp breakfasts. Works on fire, coals, or your home stove.', icon: '🍳' },
  { sku: 'FS-1006', name: 'Waxed Canvas Tool Roll', category: 'Tools', price: 3800, stock: 18,
    description: 'Twelve pockets, roll-and-buckle closure. Keeps your kit organized and your hands free.', icon: '🧰' },
  { sku: 'FS-1007', name: '4-Season Backpacking Tent', category: 'Camping', price: 34900, stock: 6,
    description: 'Freestanding two-pole design, 3000mm waterproofing, packs to the size of a loaf of bread.', icon: '⛺' },
  { sku: 'FS-1008', name: 'Insulated Steel Growler, 64oz', category: 'Kitchen', price: 3200, stock: 27,
    description: 'Double-wall vacuum insulation keeps cold drinks cold for 24 hours, hot drinks hot for 12.', icon: '🫙' },
  { sku: 'FS-1009', name: 'Leather Work Gloves', category: 'Tools', price: 2900, stock: 39,
    description: 'Full-grain cowhide palm, reinforced fingertips. They break in, not down.', icon: '🧤' },
  { sku: 'FS-1010', name: 'Down Camp Quilt', category: 'Camping', price: 15900, stock: 11,
    description: '650-fill duck down, packable to the size of a football, rated to 20°F.', icon: '🛏️' },
  { sku: 'FS-1011', name: 'Hand-Forged Camp Axe', category: 'Tools', price: 7400, stock: 15,
    description: 'Hickory handle, high-carbon steel head, leather edge guard. Splits kindling all afternoon.', icon: '🪓' },
  { sku: 'FS-1012', name: 'Wide-Brim Field Hat', category: 'Apparel', price: 4800, stock: 26,
    description: 'Treated cotton canvas, adjustable chin cord, packable crown. Shade wherever you go.', icon: '👒' }
];

const DEFAULT_DATA = {
  products: [],
  carts: [],      // { id, items: [{ productId, qty }], updatedAt }
  orders: [],     // { id, orderNumber, items, customer, subtotal, shipping, total, status, createdAt }
  nextId: { products: 1, orders: 1 }
};

function seedProducts() {
  return SEED_PRODUCTS.map((p, i) => ({ id: i + 1, ...p, createdAt: new Date().toISOString() }));
}

function load() {
  if (!fs.existsSync(DB_FILE)) {
    const initial = { ...DEFAULT_DATA, products: seedProducts(), nextId: { products: SEED_PRODUCTS.length + 1, orders: 1 } };
    fs.writeFileSync(DB_FILE, JSON.stringify(initial, null, 2));
  }
  return JSON.parse(fs.readFileSync(DB_FILE, 'utf-8'));
}

function save(data) {
  fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2));
}

let data = load();

function nextId(table) {
  return data.nextId[table]++;
}

function persist() {
  save(data);
}

function newCartId() {
  return crypto.randomUUID();
}

function orderNumber() {
  const n = data.nextId.orders;
  return 'FS-' + String(10000 + n);
}

module.exports = { data, nextId, persist, newCartId, orderNumber };
