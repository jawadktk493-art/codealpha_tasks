# Field Supply Co. — Mini E-Commerce Store

A small full-stack storefront: product catalog, product detail pages, a shopping cart, and order processing/checkout.

- **Backend:** Node.js + Express
- **Database:** a lightweight JSON file store (`db.js` / `data.json`), seeded with 12 sample products across 4 categories — zero setup required. The schema (`products`, `carts`, `orders`) is plain relational-style data, so it's a straightforward swap to Postgres/MySQL/MongoDB later.
- **Frontend:** plain HTML / CSS / JavaScript (no build step, no framework), served as static files by Express
- **No account system required** — the cart is tracked by an anonymous ID generated in the browser and stored in `localStorage`, so checkout works without signing up.

## Setup

```bash
npm install
npm start
```

Then open **http://localhost:3000**.

The server listens on port `3000` by default (override with `PORT=xxxx npm start`).
On first run it creates `data.json` next to `server.js`, seeded with the starter catalog — that file is your entire database (products, carts, and orders). Delete it to reset the store back to its seed state.

## Project structure

```
server.js        Express app + all API routes (products, cart, orders)
db.js            JSON-file "database" + seed product catalog
public/
  index.html     App shell (header, cart drawer, page templates)
  style.css      Styling
  app.js         Frontend logic: routing, catalog, product detail, cart, checkout
data.json        Created automatically — your store's data
```

## Features

- **Product listings:** grid of products with category filters, search, and price sorting
- **Product detail page:** full description, price, stock status, quantity selector
- **Shopping cart:** slide-out cart drawer, add/update/remove items, live subtotal/shipping/total, stock-aware (won't let you add more than what's in stock)
- **Order processing:** checkout form collects shipping details, validates the cart against current stock, creates an order, decrements inventory, and shows an order confirmation page with an order number you can look back up

## API reference

All endpoints are under `/api`. Cart endpoints identify the shopper via an `X-Cart-Id` header (a UUID the frontend generates once and reuses).

| Method | Endpoint                     | Description |
|--------|-------------------------------|--------------|
| GET    | `/products`                  | List products (`?category=`, `?q=`, `?sort=price-asc\|price-desc`) |
| GET    | `/products/:id`               | Single product |
| GET    | `/categories`                 | List of distinct categories |
| GET    | `/cart`                       | Current cart (via `X-Cart-Id`) |
| POST   | `/cart/items`                 | Add an item `{ productId, qty }` |
| PUT    | `/cart/items/:productId`      | Set quantity `{ qty }` |
| DELETE | `/cart/items/:productId`      | Remove an item |
| POST   | `/cart/clear`                 | Empty the cart |
| POST   | `/orders`                     | Place an order `{ customer: { name, email, address, city, zip } }` |
| GET    | `/orders/:id`                 | Look up an order by id or order number (e.g. `FS-10001`) |

## Notes on the storage layer

`db.js` keeps everything in memory and writes the full state to `data.json` after each mutation. This keeps the whole project runnable with just `npm install && npm start` — no database server, no native build tools, no `.env` config. It's plenty for a demo store; for production, swap the contents of `db.js` for real queries while keeping `server.js`'s route logic, since it only touches `data.<table>` arrays plus `nextId()` / `persist()`.

This is also not a payment integration — checkout collects shipping details and creates an order record, but no real payment is processed. Wiring in a provider like Stripe would mean adding a payment step between the "place order" click and the order-creation call.
