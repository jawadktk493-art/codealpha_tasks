(() => {
  const API = '/api';
  let cartId = localStorage.getItem('fs_cart_id') || null;

  const state = {
    products: [],
    categories: [],
    category: 'All',
    query: '',
    sort: 'default',
    cart: { items: [], itemCount: 0, subtotal: 0, shipping: 0, total: 0 }
  };

  // ---------- API helper ----------
  async function api(path, { method = 'GET', body } = {}) {
    const headers = { 'Content-Type': 'application/json' };
    if (cartId) headers['X-Cart-Id'] = cartId;
    const res = await fetch(API + path, {
      method,
      headers,
      body: body ? JSON.stringify(body) : undefined
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      const err = new Error(data.error || 'Something went wrong');
      err.payload = data;
      throw err;
    }
    return data;
  }

  function fmt(cents) {
    return '$' + (cents / 100).toFixed(2);
  }

  function escapeHtml(str) {
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
  }

  function toast(msg) {
    const el = document.createElement('div');
    el.style.cssText = 'position:fixed;bottom:22px;left:50%;transform:translateX(-50%);background:#1c2620;color:#fffdf7;font-family:"JetBrains Mono",monospace;font-size:13px;padding:10px 18px;border-radius:2px;z-index:200;box-shadow:0 4px 14px rgba(0,0,0,0.25);';
    el.textContent = msg;
    document.body.appendChild(el);
    setTimeout(() => el.remove(), 2200);
  }

  // ---------- Cart sync ----------
  async function refreshCart() {
    const { cart } = await api('/cart');
    if (!cartId && cart.id) {
      // shouldn't normally happen, but keeps things consistent
    }
    state.cart = cart;
    renderCartBadge();
    if (document.getElementById('cart-drawer').classList.contains('open')) {
      renderDrawer();
    }
  }

  function renderCartBadge() {
    const badge = document.getElementById('cart-badge');
    if (state.cart.itemCount > 0) {
      badge.textContent = state.cart.itemCount;
      badge.classList.remove('hidden');
    } else {
      badge.classList.add('hidden');
    }
  }

  async function addToCart(productId, qty) {
    try {
      const { cart } = await api('/cart/items', { method: 'POST', body: { cartId, productId, qty } });
      if (!cartId) {
        // server may have generated one implicitly; but we always send one from client.
      }
      state.cart = cart;
      renderCartBadge();
      return true;
    } catch (err) {
      toast(err.message);
      return false;
    }
  }

  function ensureCartId() {
    if (!cartId) {
      cartId = crypto.randomUUID();
      localStorage.setItem('fs_cart_id', cartId);
    }
    return cartId;
  }

  // ---------- Cart drawer ----------
  const drawer = document.getElementById('cart-drawer');
  const overlay = document.getElementById('drawer-overlay');
  const drawerBody = document.getElementById('drawer-body');
  const drawerFoot = document.getElementById('drawer-foot');
  const tplCartLine = document.getElementById('tpl-cart-line');

  function openDrawer() {
    drawer.classList.add('open');
    overlay.classList.remove('hidden');
    renderDrawer();
  }
  function closeDrawer() {
    drawer.classList.remove('open');
    overlay.classList.add('hidden');
  }
  document.getElementById('cart-toggle').addEventListener('click', openDrawer);
  document.getElementById('drawer-close').addEventListener('click', closeDrawer);
  overlay.addEventListener('click', closeDrawer);

  function renderDrawer() {
    const cart = state.cart;
    if (!cart.items.length) {
      drawerBody.innerHTML = '<div class="drawer-empty">Your manifest is empty.<br>Add some gear to get started.</div>';
      drawerFoot.innerHTML = '';
      return;
    }
    drawerBody.innerHTML = '';
    cart.items.forEach(item => drawerBody.appendChild(buildCartLine(item)));

    drawerFoot.innerHTML = `
      <div class="summary-row"><span>Subtotal</span><span>${fmt(cart.subtotal)}</span></div>
      <div class="summary-row"><span>Shipping</span><span>${cart.shipping === 0 ? 'FREE' : fmt(cart.shipping)}</span></div>
      <div class="summary-row total"><span>Total</span><span>${fmt(cart.total)}</span></div>
      <button class="btn btn-primary btn-full" id="checkout-btn">Proceed to checkout</button>
    `;
    document.getElementById('checkout-btn').addEventListener('click', () => {
      closeDrawer();
      location.hash = '#/checkout';
    });
  }

  function buildCartLine(item) {
    const node = tplCartLine.content.cloneNode(true);
    node.querySelector('.cart-line-icon').textContent = item.icon;
    node.querySelector('.cart-line-name').textContent = item.name;
    node.querySelector('.cart-line-sku').textContent = item.sku;
    node.querySelector('.cart-line-total').textContent = fmt(item.lineTotal);
    const qtyInput = node.querySelector('.qty-input');
    qtyInput.value = item.qty;
    qtyInput.max = item.inStock;

    if (item.overStock) {
      const warn = node.querySelector('.cart-line-warning');
      warn.textContent = `Only ${item.inStock} in stock — please lower quantity`;
      warn.classList.remove('hidden');
    }

    async function updateQty(newQty) {
      newQty = Math.max(1, Math.min(newQty, item.inStock));
      try {
        const { cart } = await api(`/cart/items/${item.productId}`, { method: 'PUT', body: { qty: newQty } });
        state.cart = cart;
        renderCartBadge();
        renderDrawer();
      } catch (err) { toast(err.message); }
    }

    node.querySelector('.qty-minus').addEventListener('click', () => updateQty(item.qty - 1));
    node.querySelector('.qty-plus').addEventListener('click', () => updateQty(item.qty + 1));
    qtyInput.addEventListener('change', () => updateQty(Number(qtyInput.value) || 1));

    node.querySelector('.cart-line-remove').addEventListener('click', async () => {
      try {
        const { cart } = await api(`/cart/items/${item.productId}`, { method: 'DELETE' });
        state.cart = cart;
        renderCartBadge();
        renderDrawer();
      } catch (err) { toast(err.message); }
    });

    return node;
  }

  // ---------- Router ----------
  const app = document.getElementById('app');

  async function router() {
    const hash = location.hash || '#/';
    const [, path, param] = hash.split('/');

    if (hash.startsWith('#/product/')) {
      await renderProductDetail(hash.split('/')[2]);
    } else if (hash === '#/checkout') {
      renderCheckout();
    } else if (hash.startsWith('#/order/')) {
      await renderOrderConfirmation(hash.split('/')[2]);
    } else {
      await renderCatalog();
    }
    window.scrollTo(0, 0);
  }
  window.addEventListener('hashchange', router);

  // ---------- Catalog view ----------
  const tplProductCard = document.getElementById('tpl-product-card');

  async function loadCategories() {
    if (state.categories.length) return;
    const { categories } = await api('/categories');
    state.categories = categories;
  }

  async function renderCatalog() {
    app.innerHTML = '<div class="empty-state">Loading catalog…</div>';
    await loadCategories();

    const params = new URLSearchParams();
    if (state.category !== 'All') params.set('category', state.category);
    if (state.query) params.set('q', state.query);
    if (state.sort !== 'default') params.set('sort', state.sort);

    try {
      const { products } = await api('/products?' + params.toString());
      state.products = products;
    } catch (err) {
      app.innerHTML = `<div class="empty-state">${escapeHtml(err.message)}</div>`;
      return;
    }

    app.innerHTML = `
      <div class="catalog-toolbar">
        <h1 class="catalog-title">The Catalog</h1>
        <div class="chip-row" id="category-chips"></div>
        <select class="sort-select" id="sort-select">
          <option value="default">Sort: Featured</option>
          <option value="price-asc">Price: Low to High</option>
          <option value="price-desc">Price: High to Low</option>
        </select>
      </div>
      <div class="product-grid" id="product-grid"></div>
    `;

    const chipRow = document.getElementById('category-chips');
    ['All', ...state.categories].forEach(cat => {
      const chip = document.createElement('button');
      chip.className = 'chip' + (cat === state.category ? ' active' : '');
      chip.textContent = cat;
      chip.addEventListener('click', () => { state.category = cat; renderCatalog(); });
      chipRow.appendChild(chip);
    });

    const sortSelect = document.getElementById('sort-select');
    sortSelect.value = state.sort;
    sortSelect.addEventListener('change', () => { state.sort = sortSelect.value; renderCatalog(); });

    const grid = document.getElementById('product-grid');
    if (!state.products.length) {
      grid.innerHTML = '<div class="empty-state">No gear matches that search. Try a different term or category.</div>';
      return;
    }
    state.products.forEach(p => grid.appendChild(buildProductCard(p)));
  }

  function stockFlag(product) {
    if (product.stock === 0) return { cls: 'out', label: 'Sold out' };
    if (product.stock <= 8) return { cls: 'low', label: `Low stock — ${product.stock} left` };
    return { cls: 'in', label: 'In stock' };
  }

  function buildProductCard(product) {
    const node = tplProductCard.content.cloneNode(true);
    node.querySelector('.card-icon').textContent = product.icon;
    node.querySelector('.card-sku').textContent = product.sku;
    node.querySelector('.card-name').textContent = product.name;
    node.querySelector('.card-category').textContent = product.category;
    node.querySelector('.card-price').textContent = fmt(product.price);
    const flag = stockFlag(product);
    const flagEl = node.querySelector('.stock-flag');
    flagEl.textContent = flag.label;
    flagEl.classList.add(flag.cls);

    const link = node.querySelector('.card-link');
    link.href = `#/product/${product.id}`;

    const addBtn = node.querySelector('.btn-add');
    if (product.stock === 0) {
      addBtn.disabled = true;
      addBtn.textContent = 'Sold out';
    } else {
      addBtn.addEventListener('click', async () => {
        ensureCartId();
        addBtn.textContent = 'Adding…';
        addBtn.disabled = true;
        const ok = await addToCart(product.id, 1);
        addBtn.textContent = ok ? 'Added ✓' : 'Add to cart';
        addBtn.disabled = false;
        if (ok) {
          toast(`${product.name} added to your manifest`);
          setTimeout(() => { addBtn.textContent = 'Add to cart'; }, 1400);
        }
      });
    }
    return node;
  }

  document.getElementById('search-input').addEventListener('input', debounce((e) => {
    state.query = e.target.value.trim();
    if (!location.hash || location.hash === '#/') renderCatalog();
    else location.hash = '#/';
  }, 300));

  function debounce(fn, ms) {
    let t;
    return (...args) => { clearTimeout(t); t = setTimeout(() => fn(...args), ms); };
  }

  // ---------- Product detail view ----------
  async function renderProductDetail(id) {
    app.innerHTML = '<div class="empty-state">Loading…</div>';
    try {
      const { product } = await api(`/products/${id}`);
      const flag = stockFlag(product);
      app.innerHTML = `
        <a href="#/" class="back-link">← Back to catalog</a>
        <div class="detail-layout">
          <div class="detail-visual">${product.icon}</div>
          <div class="detail-info">
            <div class="detail-sku">${escapeHtml(product.sku)}</div>
            <h1 class="detail-name">${escapeHtml(product.name)}</h1>
            <div><span class="detail-category">${escapeHtml(product.category)}</span></div>
            <div class="detail-price">${fmt(product.price)}</div>
            <div class="detail-stock stock-flag ${flag.cls}" style="display:inline-block;">${flag.label}</div>
            <p class="detail-desc">${escapeHtml(product.description)}</p>
            <div class="detail-actions">
              <div class="qty-stepper">
                <button id="detail-qty-minus" type="button">−</button>
                <input id="detail-qty-input" type="number" value="1" min="1" max="${product.stock}">
                <button id="detail-qty-plus" type="button">+</button>
              </div>
              <button class="btn btn-primary" id="detail-add-btn" ${product.stock === 0 ? 'disabled' : ''}>
                ${product.stock === 0 ? 'Sold out' : 'Add to cart'}
              </button>
            </div>
            <div class="add-feedback" id="detail-feedback"></div>
          </div>
        </div>
      `;

      const qtyInput = document.getElementById('detail-qty-input');
      document.getElementById('detail-qty-minus').addEventListener('click', () => {
        qtyInput.value = Math.max(1, Number(qtyInput.value) - 1);
      });
      document.getElementById('detail-qty-plus').addEventListener('click', () => {
        qtyInput.value = Math.min(product.stock, Number(qtyInput.value) + 1);
      });

      const addBtn = document.getElementById('detail-add-btn');
      if (addBtn) {
        addBtn.addEventListener('click', async () => {
          ensureCartId();
          const qty = Math.max(1, Number(qtyInput.value) || 1);
          const ok = await addToCart(product.id, qty);
          const feedback = document.getElementById('detail-feedback');
          feedback.textContent = ok ? `Added ${qty} to your manifest.` : '';
        });
      }
    } catch (err) {
      app.innerHTML = `<a href="#/" class="back-link">← Back to catalog</a><div class="empty-state">${escapeHtml(err.message)}</div>`;
    }
  }

  // ---------- Checkout view ----------
  function renderCheckout() {
    const cart = state.cart;
    if (!cart.items.length) {
      app.innerHTML = `
        <div class="empty-state">
          Your manifest is empty — add some gear before checking out.<br><br>
          <a href="#/" class="back-link">← Back to catalog</a>
        </div>`;
      return;
    }

    app.innerHTML = `
      <a href="#/" class="back-link">← Back to catalog</a>
      <div class="checkout-layout">
        <div class="checkout-form">
          <h2 class="form-title">Shipping details</h2>
          <form id="checkout-form">
            <div class="field-row">
              <div class="field"><label>Full name</label><input type="text" name="name" required></div>
              <div class="field"><label>Email</label><input type="email" name="email" required></div>
            </div>
            <div class="field"><label>Street address</label><input type="text" name="address" required></div>
            <div class="field-row">
              <div class="field"><label>City</label><input type="text" name="city" required></div>
              <div class="field"><label>ZIP / postal code</label><input type="text" name="zip" required></div>
            </div>
            <p class="checkout-error" id="checkout-error"></p>
            <button type="submit" class="btn btn-primary btn-full" id="place-order-btn">Place order — ${fmt(cart.total)}</button>
          </form>
        </div>
        <div class="order-summary-card">
          <h2 class="form-title">Manifest summary</h2>
          <div id="mini-lines"></div>
          <div class="summary-row"><span>Subtotal</span><span>${fmt(cart.subtotal)}</span></div>
          <div class="summary-row"><span>Shipping</span><span>${cart.shipping === 0 ? 'FREE' : fmt(cart.shipping)}</span></div>
          <div class="summary-row total"><span>Total</span><span>${fmt(cart.total)}</span></div>
        </div>
      </div>
    `;

    const miniLines = document.getElementById('mini-lines');
    cart.items.forEach(item => {
      const row = document.createElement('div');
      row.className = 'mini-line';
      row.innerHTML = `<span class="name">${item.qty}× ${escapeHtml(item.name)}</span><span class="amt">${fmt(item.lineTotal)}</span>`;
      miniLines.appendChild(row);
    });

    document.getElementById('checkout-form').addEventListener('submit', async (e) => {
      e.preventDefault();
      const fd = new FormData(e.target);
      const customer = {
        name: fd.get('name').trim(),
        email: fd.get('email').trim(),
        address: fd.get('address').trim(),
        city: fd.get('city').trim(),
        zip: fd.get('zip').trim()
      };
      const btn = document.getElementById('place-order-btn');
      const errorEl = document.getElementById('checkout-error');
      errorEl.textContent = '';
      btn.disabled = true;
      btn.textContent = 'Placing order…';
      try {
        const { order } = await api('/orders', { method: 'POST', body: { cartId, customer } });
        state.cart = { items: [], itemCount: 0, subtotal: 0, shipping: 0, total: 0 };
        renderCartBadge();
        location.hash = `#/order/${order.orderNumber}`;
      } catch (err) {
        errorEl.textContent = err.message;
        btn.disabled = false;
        btn.textContent = `Place order — ${fmt(cart.total)}`;
      }
    });
  }

  // ---------- Order confirmation ----------
  async function renderOrderConfirmation(orderId) {
    app.innerHTML = '<div class="empty-state">Loading order…</div>';
    try {
      const { order } = await api(`/orders/${orderId}`);
      app.innerHTML = `
        <div class="confirm-wrap">
          <div class="confirm-stamp">Order Confirmed</div>
          <h1 class="confirm-order-number">${escapeHtml(order.orderNumber)}</h1>
          <p class="confirm-sub">A confirmation has been noted for ${escapeHtml(order.customer.email)}. Thanks for shopping Field Supply Co.</p>
          <div class="confirm-table" id="confirm-lines"></div>
          <div class="summary-row"><span>Subtotal</span><span>${fmt(order.subtotal)}</span></div>
          <div class="summary-row"><span>Shipping</span><span>${order.shipping === 0 ? 'FREE' : fmt(order.shipping)}</span></div>
          <div class="summary-row total"><span>Total</span><span>${fmt(order.total)}</span></div>
          <p style="font-family: var(--font-mono); font-size: 12.5px; color: var(--ink-dim); margin: 18px 0 22px;">
            Shipping to: ${escapeHtml(order.customer.address)}, ${escapeHtml(order.customer.city)} ${escapeHtml(order.customer.zip)}
          </p>
          <a href="#/" class="btn btn-primary">Continue shopping</a>
        </div>
      `;
      const linesWrap = document.getElementById('confirm-lines');
      order.items.forEach(item => {
        const row = document.createElement('div');
        row.className = 'mini-line';
        row.innerHTML = `<span class="name">${item.icon} ${item.qty}× ${escapeHtml(item.name)}</span><span class="amt">${fmt(item.lineTotal)}</span>`;
        linesWrap.appendChild(row);
      });
    } catch (err) {
      app.innerHTML = `<div class="empty-state">${escapeHtml(err.message)}</div><br><a href="#/" class="back-link">← Back to catalog</a>`;
    }
  }

  // ---------- Boot ----------
  async function boot() {
    if (cartId) {
      try { await refreshCart(); } catch (e) { /* ignore */ }
    }
    router();
  }
  boot();
})();
