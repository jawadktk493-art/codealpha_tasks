const express = require('express');
const cors = require('cors');
const path = require('path');

const { data, nextId, persist, newCartId, orderNumber } = require('./db');

const app = express();
const PORT = process.env.PORT || 3000;
const SHIPPING_FLAT_CENTS = 599;
const FREE_SHIPPING_THRESHOLD_CENTS = 10000;

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// ---------- Helpers ----------

function money(cents) {
  return Math.round(cents);
}

function findProduct(id) {
  return data.products.find(p => p.id === Number(id));
}

function getOrCreateCart(cartId) {
  let cart = data.carts.find(c => c.id === cartId);
  if (!cart) {
    cart = { id: cartId || newCartId(), items: [], updatedAt: new Date().toISOString() };
    data.carts.push(cart);
    persist();
  }
  return cart;
}

function serializeCart(cart) {
  const items = cart.items.map(item => {
    const product = findProduct(item.productId);
    if (!product) return null;
    return {
      productId: product.id,
      name: product.name,
      sku: product.sku,
      icon: product.icon,
      price: product.price,
      qty: item.qty,
      lineTotal: money(product.price * item.qty),
      inStock: product.stock,
      overStock: item.qty > product.stock
    };
  }).filter(Boolean);

  const subtotal = money(items.reduce((sum, i) => sum + i.lineTotal, 0));
  const shipping = items.length === 0 ? 0 : (subtotal >= FREE_SHIPPING_THRESHOLD_CENTS ? 0 : SHIPPING_FLAT_CENTS);
  const total = money(subtotal + shipping);

  return {
    id: cart.id,
    items,
    itemCount: items.reduce((sum, i) => sum + i.qty, 0),
    subtotal,
    shipping,
    freeShippingThreshold: FREE_SHIPPING_THRESHOLD_CENTS,
    total
  };
}

function serializeProduct(p) {
  return {
    id: p.id,
    sku: p.sku,
    name: p.name,
    description: p.description,
    category: p.category,
    price: p.price,
    stock: p.stock,
    icon: p.icon,
    inStock: p.stock > 0
  };
}

function cartIdFromReq(req) {
  return req.header('X-Cart-Id') || req.query.cartId || (req.body && req.body.cartId) || null;
}

// ---------- Product routes ----------

app.get('/api/products', (req, res) => {
  let products = data.products;
  const { category, q, sort } = req.query;

  if (category && category !== 'All') {
    products = products.filter(p => p.category === category);
  }
  if (q) {
    const needle = q.toLowerCase();
    products = products.filter(p => p.name.toLowerCase().includes(needle) || p.description.toLowerCase().includes(needle));
  }

  products = products.slice();
  if (sort === 'price-asc') products.sort((a, b) => a.price - b.price);
  else if (sort === 'price-desc') products.sort((a, b) => b.price - a.price);
  else products.sort((a, b) => a.id - b.id);

  res.json({ products: products.map(serializeProduct) });
});

app.get('/api/categories', (req, res) => {
  const categories = [...new Set(data.products.map(p => p.category))].sort();
  res.json({ categories });
});

app.get('/api/products/:id', (req, res) => {
  const product = findProduct(req.params.id);
  if (!product) return res.status(404).json({ error: 'Product not found' });
  res.json({ product: serializeProduct(product) });
});

// ---------- Cart routes ----------
// Carts are anonymous and identified by a client-generated id (X-Cart-Id header),
// so checkout works without requiring an account.

app.get('/api/cart', (req, res) => {
  const cartId = cartIdFromReq(req);
  if (!cartId) return res.json({ cart: serializeCart({ id: null, items: [] }) });
  const cart = getOrCreateCart(cartId);
  res.json({ cart: serializeCart(cart) });
});

app.post('/api/cart/items', (req, res) => {
  let cartId = cartIdFromReq(req);
  const { productId, qty } = req.body || {};
  const product = findProduct(productId);
  if (!product) return res.status(404).json({ error: 'Product not found' });

  const quantity = Math.max(1, Number(qty) || 1);
  if (!cartId) cartId = newCartId();
  const cart = getOrCreateCart(cartId);

  const existing = cart.items.find(i => i.productId === product.id);
  const desiredQty = existing ? existing.qty + quantity : quantity;
  if (desiredQty > product.stock) {
    return res.status(409).json({ error: `Only ${product.stock} left in stock`, cart: serializeCart(cart) });
  }

  if (existing) existing.qty = desiredQty;
  else cart.items.push({ productId: product.id, qty: quantity });

  cart.updatedAt = new Date().toISOString();
  persist();
  res.status(201).json({ cart: serializeCart(cart) });
});

app.put('/api/cart/items/:productId', (req, res) => {
  const cartId = cartIdFromReq(req);
  if (!cartId) return res.status(400).json({ error: 'Missing cart id' });
  const cart = getOrCreateCart(cartId);
  const product = findProduct(req.params.productId);
  if (!product) return res.status(404).json({ error: 'Product not found' });

  const qty = Number(req.body && req.body.qty);
  if (!qty || qty < 1) return res.status(400).json({ error: 'Quantity must be at least 1' });
  if (qty > product.stock) return res.status(409).json({ error: `Only ${product.stock} left in stock` });

  const item = cart.items.find(i => i.productId === product.id);
  if (!item) return res.status(404).json({ error: 'Item not in cart' });
  item.qty = qty;
  cart.updatedAt = new Date().toISOString();
  persist();
  res.json({ cart: serializeCart(cart) });
});

app.delete('/api/cart/items/:productId', (req, res) => {
  const cartId = cartIdFromReq(req);
  if (!cartId) return res.status(400).json({ error: 'Missing cart id' });
  const cart = getOrCreateCart(cartId);
  cart.items = cart.items.filter(i => i.productId !== Number(req.params.productId));
  cart.updatedAt = new Date().toISOString();
  persist();
  res.json({ cart: serializeCart(cart) });
});

app.post('/api/cart/clear', (req, res) => {
  const cartId = cartIdFromReq(req);
  if (!cartId) return res.status(400).json({ error: 'Missing cart id' });
  const cart = getOrCreateCart(cartId);
  cart.items = [];
  cart.updatedAt = new Date().toISOString();
  persist();
  res.json({ cart: serializeCart(cart) });
});

// ---------- Order processing ----------

app.post('/api/orders', (req, res) => {
  const cartId = cartIdFromReq(req);
  const { customer } = req.body || {};

  if (!cartId) return res.status(400).json({ error: 'Missing cart id' });
  const cart = getOrCreateCart(cartId);
  if (!cart.items.length) return res.status(400).json({ error: 'Your cart is empty' });

  if (!customer || !customer.name || !customer.email || !customer.address || !customer.city || !customer.zip) {
    return res.status(400).json({ error: 'Please fill in all shipping details' });
  }
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(customer.email)) {
    return res.status(400).json({ error: 'Please enter a valid email address' });
  }

  // Validate stock for every line before committing anything.
  const lines = [];
  for (const item of cart.items) {
    const product = findProduct(item.productId);
    if (!product) return res.status(409).json({ error: 'One of the items in your cart no longer exists' });
    if (item.qty > product.stock) {
      return res.status(409).json({ error: `"${product.name}" only has ${product.stock} left in stock` });
    }
    lines.push({
      productId: product.id,
      name: product.name,
      sku: product.sku,
      icon: product.icon,
      price: product.price,
      qty: item.qty,
      lineTotal: money(product.price * item.qty)
    });
  }

  // Commit: decrement stock, create order, clear cart.
  for (const line of lines) {
    const product = findProduct(line.productId);
    product.stock -= line.qty;
  }

  const subtotal = money(lines.reduce((sum, l) => sum + l.lineTotal, 0));
  const shipping = subtotal >= FREE_SHIPPING_THRESHOLD_CENTS ? 0 : SHIPPING_FLAT_CENTS;
  const total = money(subtotal + shipping);

  const order = {
    id: nextId('orders'),
    orderNumber: orderNumber(),
    items: lines,
    customer: {
      name: customer.name,
      email: customer.email,
      address: customer.address,
      city: customer.city,
      zip: customer.zip
    },
    subtotal,
    shipping,
    total,
    status: 'confirmed',
    createdAt: new Date().toISOString()
  };
  data.orders.push(order);
  cart.items = [];
  cart.updatedAt = new Date().toISOString();
  persist();

  res.status(201).json({ order });
});

app.get('/api/orders/:id', (req, res) => {
  const order = data.orders.find(o => o.id === Number(req.params.id) || o.orderNumber === req.params.id);
  if (!order) return res.status(404).json({ error: 'Order not found' });
  res.json({ order });
});

// Fallback to SPA index for any non-API route
app.get(/^(?!\/api).*/, (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`Field Supply Co. server running at http://localhost:${PORT}`);
});
